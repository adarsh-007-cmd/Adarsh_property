package Entity;

public enum Status {

	CREATED, ASSIGNED, COMPLETED
}
