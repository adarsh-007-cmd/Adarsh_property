package View;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/addDeveloper")
public class addDeveloper extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("developer-name");
		String email  = req.getParameter("developer-email");
		String password  = req.getParameter("developer-password");
		String phonenumberString = req.getParameter("developer-phonenumber");
		String salaryString = req.getParameter("developer-salary");
		
		PrintWriter printWriter = resp.getWriter();

			if(name!= null && !name.isEmpty() &&
					email != null && !email.isEmpty() && password != null && !password.isEmpty() &&
					phonenumberString !=null && phonenumberString.isEmpty() && salaryString!=null && salaryString.isEmpty())
			{
				System.out.println("All fields are required :");
				return ;
			}
			try {
				
			
			
			long phonenumber = Long.parseLong(phonenumberString);
			double salary = Double.parseDouble(salaryString);
			
			 Employee developerEmployee = new Employee();
			 developerEmployee.setName(name);
			 developerEmployee.setEmail(email);
			 developerEmployee.setPassword(password);
			 developerEmployee.setPhonenumber(phonenumber);
			 developerEmployee.setSalary(salary);
			 developerEmployee.setRole("Developer");
			 
			 EmployeeDAO devdao = new EmployeeDAO();
			 devdao.saveEmployee(developerEmployee);
			 
			 
				printWriter.print("<h2>Developer Resgistered</h2>");
			
			} catch (Exception e) {
				e.printStackTrace();
				resp.getWriter().print("<h3>Error occurred</h3>");
			}
			
			
			
			
			
				
				
				
				
				
			
		
	}
	
}
