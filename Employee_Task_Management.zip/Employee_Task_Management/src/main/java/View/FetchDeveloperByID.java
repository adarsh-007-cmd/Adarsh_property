package View;

import java.io.IOException;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/fetchdeveloper")
public class FetchDeveloperByID extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int id = Integer.parseInt(req.getParameter("id"));
		
		EmployeeDAO dao = new EmployeeDAO();
		Employee employeeid  = dao.findByIdEmployees(id);
		
		if(employeeid  != null)
		{
			req.setAttribute("employeeid", employeeid);
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("update.jsp");
			requestDispatcher.forward(req, resp);
		}
		
		
	}
}
