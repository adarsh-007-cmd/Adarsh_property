package View;

import java.io.IOException;
import java.util.List;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewallDeveloperwithtask")
public class ViewDeveloper extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		EmployeeDAO dao1 = new EmployeeDAO();
		
		List<Employee> list =  dao1.getDeveloperwithEmployeeTask();
		
		req.setAttribute("list", list);
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("/viewallDeveloperwithtask.jsp");
		requestDispatcher.forward(req, resp);
		
		
	}
	
}
