package View;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;



import DAO.EmployeeDAO;
import DAO.TaskDAO;
import Entity.Employee;
import Entity.Status;
import Entity.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/assigntask")
public class Assigntask extends HttpServlet{
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String idString = req.getParameter("id");
			String taskidString = req.getParameter("taskid");
			PrintWriter printWriter = resp.getWriter();
			
			if(idString != null && !idString.isEmpty() || taskidString != null && !taskidString.isEmpty())
			{
				printWriter.print("Fields are required");
			}
			
			
			
			try {
				
				int id = Integer.parseInt(idString);
				int taskid = Integer.parseInt(taskidString);
				
				
				EmployeeDAO dao4 = new EmployeeDAO();
				Employee dbemployee = dao4.findByIdEmployees(id);
				
				TaskDAO dao5 = new TaskDAO();
				Task taskdb = dao5.findbyTaskid(taskid);
				
				taskdb.setEmployee(dbemployee);
				
				List<Task> tasklist = dbemployee.getTasklist();
				
				if(tasklist == null)
				{
					tasklist = new ArrayList<Task>();
				}
				
				taskdb.setStatus(Status.ASSIGNED);
				dao5.mergeTask(taskdb);
				tasklist.add(taskdb);
				dbemployee.setTasklist(tasklist);
				
				dao4.mergeEmployee(dbemployee);
				printWriter.print("<h2>Task Assigned</>");
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

}
