package View;

import java.io.IOException;
import java.io.PrintWriter;


import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/check")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String employeeEmail = req.getParameter("employee-email");
		String employeePassword = req.getParameter("employee-password");
		
		PrintWriter printWriter = resp.getWriter();
		
		EmployeeDAO dao = new EmployeeDAO();
		Employee dbEmployee = dao.findByEmailandPassword(employeeEmail,employeePassword);
		if(dbEmployee!=null)
		{
			printWriter.print("<h1>Login Successful. Welcome !</h1>");
			String role = dbEmployee.getRole();
			if(role.equals("manager"))
					{
						RequestDispatcher requestDispatcher = req.getRequestDispatcher("ManagerDashboard.html");
						requestDispatcher.include(req, resp);
					}
			
		else if(role.equals("Developer")){
			
			long employeeid = dbEmployee.getId();
			HttpSession session = req.getSession();
			session.setAttribute("employeeID", employeeid);
			
			
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("DevelopeDashboard.html");
			requestDispatcher.forward(req, resp);
			
			
			
		}
			
			
					
		
	}
		else {
			printWriter.print("<h1>Login Failure.Try Again !</h1>");
		}
}
}
