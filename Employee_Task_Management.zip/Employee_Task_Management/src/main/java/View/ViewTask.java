package View;

import java.io.IOException;
import java.io.PrintWriter;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/viewtask")
public class ViewTask extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session =  req.getSession(false);
		PrintWriter printWriter = resp.getWriter();
		
		if(session == null || session.getAttribute("employeeID") == null) {
			printWriter.print("Session expired.");
			return;
		}
		long employeeid = (Long) session.getAttribute("employeeID");
		
		EmployeeDAO dao = new EmployeeDAO();
		Employee dbEmployee = dao.findByIdEmployees(employeeid);
		
		if(dbEmployee != null)
		{
			req.setAttribute("dbEmployee", dbEmployee);
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("/viewtask.jsp");
			requestDispatcher.forward(req, resp);
		}
	}

}
