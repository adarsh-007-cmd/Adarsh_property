package View;


import java.io.IOException;
import java.io.PrintWriter;

import DAO.TaskDAO;
import Entity.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/changetaskstatus")
public class ChangeTaskStatus extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String taskidString = req.getParameter("taskid");
		String taskstatusString = req.getParameter("status");
		PrintWriter printWriter = resp.getWriter();
		
		if(taskidString != null && !taskidString.isEmpty() || taskstatusString != null && !taskstatusString.isEmpty())
		{
			printWriter.print("Fields are required ");
		}
		
		try {
			
			long taskid = Long.parseLong(taskidString);
			
			TaskDAO taskDAO = new TaskDAO();
			
			Task task = taskDAO.findbyTaskid(taskid);
			
			
			if(task != null ) {
				
				Entity.Status status = Entity.Status.valueOf(taskstatusString);
				task.setStatus(status);
				taskDAO.mergeTask(task);
				
				printWriter.print("Status has been set successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
