package View;

import java.io.IOException;
import java.io.PrintWriter;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterManager extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String phonenumberString = req.getParameter("phonenumber");
		String salaryString = req.getParameter("salary");
		
		if(name!= null && !name.isEmpty() &&
				email != null && !email.isEmpty() && password != null && !password.isEmpty() &&
				phonenumberString !=null && phonenumberString.isEmpty() && salaryString!=null && salaryString.isEmpty())
		{
			System.out.println("All fields are required :");
			return ;
		}
		
		try {
		
		
		long phonenumber = Long.parseLong(phonenumberString);
		double salary = Double.parseDouble(salaryString);
		
		
		Employee employee = new Employee();
		employee.setName(name);
		employee.setEmail(email);
		employee.setPassword(password);
		employee.setPhonenumber(phonenumber);
		employee.setSalary(salary);
		employee.setRole("manager");
		
		EmployeeDAO dao = new EmployeeDAO();
		dao.saveEmployee(employee);
		
		PrintWriter printWriter = resp.getWriter();
		printWriter.print("<h2>Manager Resgistered</h2>");
	}
		catch (Exception e) {
			e.printStackTrace();
			resp.getWriter().print("<h3>Error occurred</h3>");
		}
}
}
