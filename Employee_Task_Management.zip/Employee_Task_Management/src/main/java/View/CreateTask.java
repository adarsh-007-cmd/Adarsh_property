package View;

import java.io.IOException;
import java.io.PrintWriter;

import DAO.TaskDAO;
import Entity.Status;
import Entity.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/createtask")
public class CreateTask extends HttpServlet{

		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			
			String tasknameString = req.getParameter("taskname");
			String duration = req.getParameter("duration");
			
			PrintWriter printWriter = resp.getWriter();
			
			Task task = new Task();
			task.setTaskname(tasknameString);
			task.setDays(Integer.parseInt(duration));
			task.setStatus(Status.CREATED);
			
			TaskDAO taskDAO = new TaskDAO();
			taskDAO.saveTask(task);
			
			printWriter.print("<h2>TASK CREATED</h2>");
			
		}
}
