package View;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteDeveloper")
public class Delete extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String idString = req.getParameter("id");
		PrintWriter printWriter = resp.getWriter();
		
		if(idString!= null && !idString.isEmpty())
		{
			printWriter.print("<h2>Fields are required</h2>");
		}
		
		try {
			
			
			Long id = Long.parseLong(idString);
			EmployeeDAO dao2 = new EmployeeDAO();
			String message = dao2.deleteEmployeeById(id);
			
			req.setAttribute("msg", message);
			 
			 RequestDispatcher requestDispatcher = req.getRequestDispatcher("DeletedEmployee.jsp");
			 requestDispatcher.forward(req, resp);
			 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
