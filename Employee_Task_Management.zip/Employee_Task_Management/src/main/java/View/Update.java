package View;

import java.io.IOException;
import java.io.PrintWriter;

import DAO.EmployeeDAO;
import Entity.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/update")
public class Update extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String idString = req.getParameter("developer-id");
		String name = req.getParameter("developer-name");
		String email  = req.getParameter("developer-email");
		String password  = req.getParameter("developer-password");
		String phonenumberString = req.getParameter("developer-phonenumber");
		String salaryString = req.getParameter("developer-salary");
		
		PrintWriter printWriter = resp.getWriter();

		if (idString == null || idString.isEmpty() ||
			    name == null || name.isEmpty() ||
			    email == null || email.isEmpty() ||
			    password == null || password.isEmpty() ||
			    phonenumberString == null || phonenumberString.isEmpty() ||
			    salaryString == null || salaryString.isEmpty()) {

			    printWriter.print("All fields are required");
			    return;
			}
		
			try {
				
			
			long id = Long.parseLong(idString);
			long phonenumber = Long.parseLong(phonenumberString);
			double salary = Double.parseDouble(salaryString);
			
			EmployeeDAO devdao = new EmployeeDAO();
			 
			
			  
			 
			  Employee employeeid = devdao.findByIdEmployees(id);
			  
			 if(employeeid == null) {
				 
				 printWriter.print("Employee not found");
				 return;
				 
			 }
			 
			 
			 employeeid.setName(name);
			 employeeid.setEmail(email);
			 employeeid.setPassword(password);
			 employeeid.setPhonenumber(phonenumber);
			 employeeid.setSalary(salary);
			 
			 
			 devdao.mergeEmployee(employeeid);
			 printWriter.print("Developer Updated");
			 
			 
			 
			 
				
			
			} catch (Exception e) {
				e.printStackTrace();
				resp.getWriter().print("Error occurred");
			}
	}
}
