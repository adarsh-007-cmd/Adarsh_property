package DAO;

import java.util.List;



import Entity.Task;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class TaskDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev1");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	public Task saveTask(Task task)
	{
		transaction.begin();
		manager.persist(task);
		transaction.commit();
		return task;
		
	}
	public Task mergeTask(Task task)
	{
		transaction.begin();
		manager.merge(task);
		transaction.commit();
		return task;
		
	}
	public Task deleteTask(Task task)
	{
		transaction.begin();
		manager.remove(task);
		transaction.commit();
		return task;
		
	}
	public Task findbyTaskid(long taskid)
	{
		
		return manager.find(Task.class, taskid);
	}
	public List<Task> fetchTask()
	{
		Query query = manager.createQuery("select task from Task task");
		List<Task> taskList = query.getResultList();
		
		if(taskList.size()>0)
		{
			return taskList;
		}
		return null;
	}
	
}
