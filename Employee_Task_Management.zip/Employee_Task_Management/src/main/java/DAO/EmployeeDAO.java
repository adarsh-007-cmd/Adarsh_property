package DAO;


import java.util.List;

import Entity.Employee;
import Entity.Task;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class EmployeeDAO {


	
	private static EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev1");
	
					EntityManager manager = factory.createEntityManager();
					EntityTransaction transaction = manager.getTransaction();
		
		public Employee saveEmployee(Employee employee)
		{
			transaction.begin();
			manager.persist(employee);
			transaction.commit();
			return employee;
		}
		public Employee mergeEmployee(Employee employee)
		{
			transaction.begin();
			manager.merge(employee);
			transaction.commit();
			return employee;
		}
		public Employee deleteEmployee(Employee employee)
		{
			transaction.begin();
			manager.remove(employee);
			transaction.commit();
			return employee;
		}
		public Employee findByIdEmployees(long id)
		{
			return manager.find(Employee.class,id);
			
		}
		public List<Employee> fetchEmployees()
		{
			Query query = manager.createQuery("select employee from Employee employee");
			List<Employee> employeesList = query.getResultList();
			
			if(employeesList.size()>0)
			{
				return employeesList;
			}
			return null;
		}
		
		public Employee findByEmailandPassword(String email,String password)
		{
			Query query = manager.createQuery("select employee from Employee employee where employee.email=?1 and employee.password=?2");
			query.setParameter(1, email);
			query.setParameter(2, password);
			List<Employee> employeeList = query.getResultList();
			if(employeeList.size()>0)
			{
				return employeeList.get(0);
			}
			return null;
		}
		
		public List<Employee> getDeveloperwithEmployeeTask()
		{
			Query query = manager.createQuery("select employee from Employee employee where employee.role = 'Developer'");
			
			List<Employee> employeesList = query.getResultList();
			
			return employeesList;
			
		}
		public String deleteEmployeeById(long id)
		{
			Employee emp = manager.find(Employee.class, id);

		    if (emp != null)
		    {
		    	transaction.begin();
		        manager.remove(emp);
		        transaction.commit();
		        return "Employee deleted successfully";
		    }
		    else
		    {
		        
		        return "Employee not found";
		    }
		}
		public String taskassign(int id, int taskid)
		
		{
			Employee query = manager.find(Employee.class, id);
			Task task = manager.find(Task.class, taskid);
			if(query !=null && task != null)
			{
				transaction.begin();
				task.setEmployee(query);
				manager.persist(task);
				transaction.commit();
				return "Task assigned successfully";
			}
			else {
				return " Task or Developer not found";
			}
		}
		
		public Employee updateEmployee()
		{
			return null;
		}
		
}
		
	


