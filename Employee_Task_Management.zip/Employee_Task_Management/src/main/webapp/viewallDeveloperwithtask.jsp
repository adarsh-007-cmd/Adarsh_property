<%@page import="Entity.Employee"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Developers</title>
</head>
<body>
	
	<h2> All Developers</h2>
	
	<table border="1">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Email</th>
		<th>Password</th>
		<th>Phone number</th>
		<th>Salary</th>
		<th>role</th>
	</tr>
	
		<%
		
			List<Employee> list =  (List<Employee>) request.getAttribute("list");
		
		if(list != null && !list.isEmpty())
		{
			for(Employee emp : list)
			{
				%>
				<tr>
					<td><%= emp.getId() %></td>
					<td><%= emp.getName() %></td>
					<td><%= emp.getEmail() %></td>
					<td><%= emp.getPassword() %></td>
					<td><%= emp.getPhonenumber() %></td>
					<td><%= emp.getSalary() %></td>
					<td><%= emp.getRole() %></td>
				</tr>
				<% 
			}
		}
		
		%>
	
	
	</table>
	
</body>
</html>