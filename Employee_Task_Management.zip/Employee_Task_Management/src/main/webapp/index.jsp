<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome Page</title>
</head>
<%
    String name = "Adarsh";
%>

<h1>Welcome To Our Official Page, <%= name %></h1>
<body>

<h3><a href="registerManager.html">Register New Manager</a></h3>
<h3><a href="login.html">Login Your Manager Account</a></h3>
<h3><a href="login.html">Login Your Developer Account</a></h3>
</body>
</html>