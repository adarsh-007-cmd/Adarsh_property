<%@page import="Entity.Task"%>
<%@page import="java.util.List"%>
<%@page import="Entity.Employee"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View - Task</title>
</head>
<body>

<h1>View Task</h1>



<%
    Employee employee = (Employee) request.getAttribute("dbEmployee");

    if (employee == null) {
%>
        <h3>Employee not found</h3>
<%
        return;
    }

    List<Task> list = employee.getTasklist();

    if (list == null || list.isEmpty()) {
%>
        <h3>No tasks assigned</h3>
<%
    } else {
        for (Task task : list) {
%>

        <div>
            <b>ID:</b> <%=task.getTaskid() %> <br>
            <b>Name:</b> <%=task.getTaskname() %> <br>
            <b>Status:</b> <%=task.getStatus() %>
        </div>
        <hr>

<%
        }
    }
%>

</body>
</html>


