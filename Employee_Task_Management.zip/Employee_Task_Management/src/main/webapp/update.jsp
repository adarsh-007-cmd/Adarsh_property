<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Updation Page</title>
</head>
<body>
	
		<form action="update" method="get">

ID:
<input type="text" name="developer-id" value="${employeeid.id}" readonly><br><br>

NAME:
<input type="text" name="developer-name" value="${employeeid.name}"><br><br>

EMAIL:
<input type="text" name="developer-email" value="${employeeid.email}"><br><br>

PASSWORD:
<input type="password" name="developer-password" value="${employeeid.password}"><br><br>

PHONE:
<input type="number" name="developer-phonenumber" value="${employeeid.phonenumber}"><br><br>

SALARY:
<input type="number" name="developer-salary" value="${employeeid.salary}"><br><br>

<input type="submit" value="Update">

</form>

</body>
</html>