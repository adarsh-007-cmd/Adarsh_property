<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>
</head>
<body>
<h2>Login Credentials</h2>
	<form action="loginhere" method="post">
    USERNAME: <input type="text" name="username" placeholder="Enter a username"><br><br>
    PASSWORD: <input type="password" name="userpassword" placeholder="Enter a strong password"><br><br>
    <input type="submit" value="Login">
</form>
</body>
</html>