<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Role</title>
</head>
<body>
<%
	String username = (String) request.getAttribute("username");
	if(username.equals("admin"))
	{
		response.sendRedirect("AdminDash.html");
	}
	else if(username.equals(username))
	{
		response.sendRedirect("UserDash.html");
	}
%>
	
</body>
</html>