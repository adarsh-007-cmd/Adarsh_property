package servlet_jsp_practise_project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginhere")
public class LoginServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String username = req.getParameter("username");
		String userpassword = req.getParameter("userpassword");
		
		try {
			
			Class.forName("org.postgresql.Driver");
			
			Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ProjectDB","postgres","postregsql");
			PreparedStatement pStatement = connect.prepareStatement("select *from mydb3 where username=? and userpassword=?"); 
			
			pStatement.setString(1, username);
			pStatement.setString(2, userpassword);
			
			ResultSet rSet = pStatement.executeQuery();
			
			if(rSet.next())
			{
				req.setAttribute("username", rSet.getString("username"));
			}
			connect.close();
			
			} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(username.equals("admin") && userpassword.equals("admin123") || username.equals(username) && userpassword.equals(userpassword))
		{
			req.setAttribute("username",username);
			RequestDispatcher rDispatcher = req.getRequestDispatcher("/role.jsp");
			rDispatcher.forward(req, resp);
		}
		else {
			req.setAttribute("Error","Username OR Password Not Found");
            RequestDispatcher rd = req.getRequestDispatcher("/login.jsp");
            rd.include(req, resp);
		}
		
		
	} 
		
	}

