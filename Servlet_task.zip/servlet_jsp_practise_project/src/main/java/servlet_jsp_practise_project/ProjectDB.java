package servlet_jsp_practise_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ProjectDB {
public static void main(String[] args) {
	try {
Class.forName("org.postgresql.Driver");
		
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ProjectDB","postgres","postregsql");
		PreparedStatement user_add = connect.prepareStatement("insert into mydb3(username,userpassword) values(?,?)");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the user Name :");
		String username = scan.nextLine();
		
		System.out.println("Enter a strong Password :");
		String userpassword = scan.next();
		
		
		user_add.setString(1, username);
		user_add.setString(2,userpassword);
		
		user_add.execute();
		
		System.out.println(" A new user details has been added");
		 connect.close();
		scan.close();
		
	} catch (Exception e) {
		e.printStackTrace();
		
	}
}
}
