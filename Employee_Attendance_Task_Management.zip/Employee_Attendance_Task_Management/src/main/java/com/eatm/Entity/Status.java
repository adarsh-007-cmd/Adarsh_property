package com.eatm.Entity;

public enum Status {

	CREATED, ASSIGNED, COMPLETED
}
