package com.eatm.Entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Component
@Scope(value = "prototype")
public class Attendance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY ,generator = "attendanceid_generator")
	@SequenceGenerator(name = "attendanceid_generator", allocationSize = 1, initialValue = 301)
	private int attendanceid;
	@CreationTimestamp
	private LocalDateTime loginTime;
	private LocalDateTime logoutTime;
}
