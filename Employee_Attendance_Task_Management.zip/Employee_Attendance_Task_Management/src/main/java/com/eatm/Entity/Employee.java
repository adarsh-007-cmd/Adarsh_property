package com.eatm.Entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Employee {



		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;
		
		private String name;
		
		@Column(nullable = false, unique = true)
		private String email;
		
		@Column(nullable = false)
		private String password;
		
		@Column(unique = true)
		private long phonenumber;
		
		private double salary;
		private String role;
		
		@OneToMany(mappedBy = "employee")
		private List<Task> tasklist;
		
		@OneToOne(mappedBy = "employee", cascade = CascadeType.ALL)
		private Address address;
		
		@OneToMany
		private List<Attendance> attendancelist;
		
}
