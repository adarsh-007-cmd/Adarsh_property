package com.eatm.Entity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY , generator = "addressid_generator")
	@SequenceGenerator(name = "addressid_generator" , initialValue = 201, allocationSize = 1)
	private int addressid;
	
	private int housenumber;
	private String street;
	private String city;
	private String state;
	private String country;
	private long pincode;
	
	@OneToOne
	@JoinColumn(name = "employee_id")  
	private Employee employee;
}
