package com.eatm.DTO;

import java.util.List;

import com.eatm.Entity.Address;
import com.eatm.Entity.Attendance;
import com.eatm.Entity.Task;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class EmployeeDTO {
	
	private Long id;
	private String name;
	private String email;
	private String password;
	private long phonenumber;
	private double salary;
	private String role;
	
	private List<Task> tasklist;
	
	private Address address;
	
	private List<Attendance> attendancelistAttendances;
}
