package com.eatm.DTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AddressDTO {

	private int housenumber;
	private String street;
	private String city;
	private String state;
	private String country;
	private long pincode;
}
