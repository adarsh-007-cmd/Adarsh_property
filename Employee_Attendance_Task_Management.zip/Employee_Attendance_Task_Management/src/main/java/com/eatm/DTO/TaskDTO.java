package com.eatm.DTO;

import com.eatm.Entity.Employee;
import com.eatm.Entity.Status;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class TaskDTO {
private long taskid;
	
	private String taskname;
	private int days;
	private Status status;
	
	private Employee employee;
}
