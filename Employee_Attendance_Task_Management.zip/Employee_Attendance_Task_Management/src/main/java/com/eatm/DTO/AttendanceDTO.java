package com.eatm.DTO;

import java.time.LocalDateTime;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AttendanceDTO {

	private int attendanceid;
	private LocalDateTime loginTime;
	private LocalDateTime logoutTime;
}
