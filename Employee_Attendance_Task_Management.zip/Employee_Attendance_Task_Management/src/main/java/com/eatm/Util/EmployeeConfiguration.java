package com.eatm.Util;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;


@Configuration
@ComponentScan(basePackages =  "com.eatm")
public class EmployeeConfiguration  {

	@Bean
	public EntityManager getEntityManager()
	{
		return Persistence.createEntityManagerFactory("dev1").createEntityManager();
	}
	@Bean
	public EntityTransaction getEntityTransaction()
	{
		return getEntityManager().getTransaction();
	}
	@Bean
	public ModelMapper getmodelMapper()
	{
		return new ModelMapper();
	}
	
	    @Bean
	    public InternalResourceViewResolver viewResolver() {
	        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	        resolver.setPrefix("/WEB-INF/view/");
	        resolver.setSuffix(".jsp");
	        return resolver;
	    }
	    
	}



