package com.eatm.Service;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.eatm.DTO.AddressDTO;
import com.eatm.DTO.EmployeeDTO;
import com.eatm.DTO.TaskDTO;
import com.eatm.Entity.Address;
import com.eatm.Entity.Attendance;
import com.eatm.Entity.Employee;
import com.eatm.Entity.Status;
import com.eatm.Entity.Task;
import com.eatm.dao.AddressDAO;
import com.eatm.dao.AttendanceDAO;
import com.eatm.dao.EmployeeDAO;
import com.eatm.dao.TaskDAO;

import jakarta.persistence.Entity;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Service
public class EmployeeService {
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	EmployeeDAO employeeDAO;
	
	@Autowired
	AddressDAO addressDAO;
	
	@Autowired
	TaskDAO taskDAO;
	
	@Autowired
	AttendanceDAO attendanceDAO;
	
	@Autowired
	Attendance attendance;
	
	
	Status status;
	
	
	
	@Transactional
	public String registermanager(EmployeeDTO employeeDTO, AddressDTO addressDTO)
	{
		Employee employee = modelMapper.map(employeeDTO, Employee.class);
		employee.setRole("manager");
		Address address = modelMapper.map(addressDTO, Address.class);
		
		address.setEmployee(employee);
		employee.setAddress(address);
	    

	    
	    employeeDAO.saveEmployee(employee);
		
		return "success";
		
	}
	@Transactional
	public String registerdeveloper(EmployeeDTO employeeDTO, AddressDTO addressDTO)
	{
		Employee employeedev = modelMapper.map(employeeDTO, Employee.class);
		employeedev.setRole("developer");
		Address address = modelMapper.map(addressDTO, Address.class);
		address.setEmployee(employeedev);
		employeedev.setAddress(address);
		
		employeeDAO.saveEmployee(employeedev);
		return "success";
	}
	
	@Transactional
	public Employee loginEmployee(String email, String password)
	{
	    return employeeDAO.findByemailandpassword(email, password);
	}
	
	@Transactional
	public String createTask(TaskDTO taskDTO)
	{
		Task createTask = modelMapper.map(taskDTO, Task.class);
		
		createTask.setStatus(Status.CREATED);
		
		taskDAO.saveTask(createTask);
		
		return "success";
	}
	
	@Transactional
	public String assignTask(long taskid,long employeeid)
	{
		Task task = taskDAO.findbyTaskid(taskid);
		Employee employee = employeeDAO.findByIdEmployees(employeeid);
		if(task !=null && employee != null)
		{
			task.setEmployee(employee);
			task.setStatus(Status.ASSIGNED);
			taskDAO.saveTask(task);
			
			return "success";
			
		}
		else {
			
			return "loginpage";
		}
		
	}
	
	@Transactional
	public String verifyemail(String email, Model model)
	{
		Employee employee = employeeDAO.findByemail(email);
		if(employee !=null)
		{
			employeeDAO.fetchEmployees();
			model.addAttribute("email",email);
			return "password";
		}
		else {
			model.addAttribute("error", "Email not found");
	        return "verifyemail";
		}
	}
	@Transactional
	public Employee findByEmail(String email) {
		
		return employeeDAO.findByemail(email);
		
	}
	@Transactional
	public void updateEmployee(Employee employee)
	{
	    employeeDAO.mergeEmployee(employee);
	}
	@Transactional
	public List<Task> viewallTaskwithdevelopers()
	{
		return taskDAO.viewallTaskwithdevelopers();
	}
	
	
	@Transactional
	public String deleteDeveloper(long id)
	{
		Employee employee = employeeDAO.findByIdEmployees(id);
		
		if(employee != null)
		{
			employeeDAO.deleteEmployee(employee);
		}
		return "success";
	}
	@Transactional
	public String deleteTask(long id)
	{
		Task deleteTask = taskDAO.findbyTaskid(id);
		
		if(deleteTask != null)
		{
			taskDAO.deleteTask(deleteTask);
		}
		return "success";
	}
	
	@Transactional
	public String logout(long id)
	{
		Attendance attendance = attendanceDAO.findbyAttendanceId(id);
		if(attendance != null)
		{
			attendance.setLogoutTime(LocalDateTime.now());
			attendanceDAO.mergeAttendance(attendance);
		}

		return "success";
	}
	
	
	
	
	
	
	//>>>>>>>>>>>>>>>>>>>>>>>DEVELOPER OPERATIONS<<<<<<<<<<<<<<<<<<<
	@Transactional
	public Employee getemployeeByid(long id)
	{
		
		return employeeDAO.findByIdEmployees(id);
	}
		
	@Transactional
	public Employee updateemployee(Employee employee)
	{
		String role = employee.getRole();
		if(role.equals("developer"))
		{
		  employee =  employeeDAO.mergeEmployee(employee);
		}
		return employee;
		
	}
	@Transactional
	public Task getTaskid(long id)
	{
		return taskDAO.findbyTaskid(id);
	}
	@Transactional
	public String updateStatus(Task task)
	{
		Task status = taskDAO.findbyTaskid(task.getTaskid());
		status.setStatus(task.getStatus());
		taskDAO.mergeTask(status);
		return "success";
	}
	

}
