package com.eatm.Service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eatm.Entity.Attendance;
import com.eatm.Entity.Task;
import com.eatm.dao.AddressDAO;
import com.eatm.dao.AttendanceDAO;
import com.eatm.dao.EmployeeDAO;
import com.eatm.dao.TaskDAO;

import jakarta.transaction.Transactional;
@Service
public class TaskService {

	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	EmployeeDAO employeeDAO;
	
	@Autowired
	AddressDAO addressDAO;
	
	@Autowired
	TaskDAO taskDAO;
	
	@Autowired
	AttendanceDAO attendanceDAO;
	
	@Autowired
	Attendance attendance;
	
	@Transactional
	public List<Task> getTaskByEmployeeId(long id )
	{
		return taskDAO.fetchTaskByEmployeeId(id);
	}
}
