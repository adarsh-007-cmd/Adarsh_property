package com.eatm.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.eatm.DTO.AddressDTO;
import com.eatm.DTO.EmployeeDTO;
import com.eatm.DTO.TaskDTO;
import com.eatm.Entity.Employee;
import com.eatm.Entity.Status;
import com.eatm.Entity.Task;
import com.eatm.Service.EmployeeService;
import com.eatm.Service.TaskService;
import com.eatm.dao.EmployeeDAO;

import jakarta.servlet.http.HttpSession;



@org.springframework.stereotype.Controller

public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	EmployeeService taskEmployeeService;
	
	@Autowired
	TaskService taskService;
	
	
	
	
	
	@RequestMapping("/registermanager")
	public String registermananger(@ModelAttribute EmployeeDTO employeeDTO ,@ModelAttribute AddressDTO addressDTO)
	{
		return employeeService.registermanager(employeeDTO, addressDTO);
	}
	
	
	/* //login
	@RequestMapping("/Login_page")
	public String login(@RequestParam(value = "email", required = false) String email, @RequestParam(value = "password", required = false) String password)
	{
		if (email == null || password == null) {
	        return "Login_page"; 
	    }
		return employeeService.loginEmployee(email,password);
	}
	*/
	@RequestMapping("/Login_page")
	public String login(@RequestParam(value = "email", required = false) String email,@RequestParam(value = "password", required = false) String password,HttpSession session)
	{
	    if (email == null || password == null) {
	        return "Login_page";
	    }

	    Employee employee = employeeService.loginEmployee(email, password);

	    if (employee != null)
	    {
	        session.setAttribute("employee", employee); 

	        if (employee.getRole().equals("manager")) {
	            return "manager";
	        } else if(employee.getRole().equals("developer")){
	            return "DeveloperDashboard";
	        }
	    }

	    return "Login_page";
	}

	

	@RequestMapping("/verifyEmail")
	public String verify(@RequestParam("email") String email, Model model)
	{
		return employeeService.verifyemail(email, model);
	}
	@RequestMapping("/password")
	public String resetPassword(@RequestParam("email") String email,@RequestParam("password") String password)
	{
	    Employee employee = employeeService.findByEmail(email);

	    if(employee != null)
	    {
	        employee.setPassword(password); 
	        employeeService.updateemployee(employee);
	        return "Login_page";
	    }

	    return "verifyemail";
	}
	
	
	
	
	
	
	
	@RequestMapping("/DeveloperDashboard")
	public String developerDashboard() {
	    return "DeveloperDashboard";
	}
	
	@RequestMapping("/manager")
	public String managerDashboard() {
	    return "manager";
	}
	
	
	@RequestMapping("/addDevloper")
	public String registerdeveloper(@ModelAttribute EmployeeDTO employeeDTO,@ModelAttribute AddressDTO addressDTO)
	{
		return employeeService.registerdeveloper(employeeDTO,addressDTO );
		
	}
	
	
	
	@RequestMapping("/createtask")
	public String createTask(@ModelAttribute TaskDTO taskDTO)
	{
		return taskEmployeeService.createTask(taskDTO);
	}
	
	@RequestMapping("/assignTask")
	public String assignTask(@RequestParam("taskid") long taskid , @RequestParam("employeeid") long employeeid)
	{
		return taskEmployeeService.assignTask(taskid,employeeid);
	}
	
	
	
	@RequestMapping("/viewalltaskwithdevelopers")
	public String viewallTaskwithdevelopers(Model model)
	{
		List<Task> tasklist = taskEmployeeService.viewallTaskwithdevelopers();
		model.addAttribute("tasklist",tasklist);
		return "viewalltaskwithdevelopers";
		
	}
	
	
	@RequestMapping("/deleteDeveloper")
	public String deleteDeveloper(@RequestParam("id") int id)
	{
		return employeeService.deleteDeveloper(id);
	}
	
	
	
	@RequestMapping("/deleteTask")
	public String deleteTask(@RequestParam("id") int id)
	{
		return taskEmployeeService.deleteTask(id);
	}
	
	
	@RequestMapping("/logout")
	public String logout(@RequestParam("id") long id)
	{
		return employeeService.logout(id);
	}
	
	
	//DEVELOPER METHODS
	@RequestMapping("/fetchdeveloper")
	public String fetchDeveloper(@RequestParam("employeeid") long id, Model model)
	{
		Employee employeeid = employeeService.getemployeeByid(id);
		model.addAttribute("employee", employeeid);
		
		return "updation2";
	}
	@RequestMapping("/update")
	public String updateDeveloper(@ModelAttribute Employee employee)
	{ 
	
		employeeService.updateemployee(employee);
		return "success";
	}
	
	@RequestMapping("/changetaskstatus")
    public String getTaskId(@RequestParam("taskid") long id, Model model) {

        Task task = taskEmployeeService.getTaskid(id);
        model.addAttribute("task", task);

        return "changetaskstatus"; 
    }
	@RequestMapping("/taskid")
	public String updateTask(@ModelAttribute Task task)
	{
		taskEmployeeService.updateStatus(task);
		return "success";
	}
	
	//view task
	@RequestMapping("/viewtask")
	public String viewTask(HttpSession session , Model model)
	{
		Employee employee = (Employee) session.getAttribute("employee");
		if(employee != null)
		{
			List<Task> tasks = taskService.getTaskByEmployeeId(employee.getId());
			model.addAttribute("tasklist",tasks);
			return "viewtask";
			
		}
		return "success";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("/success")
	public String successpage()
	{
		return "success";
	}
}
