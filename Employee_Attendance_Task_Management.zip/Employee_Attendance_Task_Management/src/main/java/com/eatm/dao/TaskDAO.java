package com.eatm.dao;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.eatm.Entity.Employee;
import com.eatm.Entity.Task;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

@Repository
public class TaskDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev1");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	public Task saveTask(Task task)
	{
		transaction.begin();
		manager.persist(task);
		transaction.commit();
		return task;
		
	}
	public Task mergeTask(Task task)
	{
		transaction.begin();
		manager.merge(task);
		transaction.commit();
		return task;
		
	}
	public Task deleteTask(Task task)
	{
		transaction.begin();
		manager.remove(task);
		transaction.commit();
		return task;
		
	}
	public Task findbyTaskid(long id)
	{
		
		return manager.find(Task.class, id);
	}
	public List<Task> viewallTaskwithdevelopers()
	{
	    List<Task> taskList = manager.createQuery("select task from Task task left join fetch task.employee",Task.class).getResultList();
		return taskList; 
	}
	
	public List<Task> getAllTasks() {
	    Query query = manager.createQuery("select task from Task task join fetch task.employee");
	    return query.getResultList();
	}
	public List<Task> fetchTaskByEmployeeId(long id)
	{
		Query query = manager.createQuery("select task from Task task where task.employee.id = :id");
		query.setParameter("id", id);
		
		return query.getResultList();
	}
}
	
	
