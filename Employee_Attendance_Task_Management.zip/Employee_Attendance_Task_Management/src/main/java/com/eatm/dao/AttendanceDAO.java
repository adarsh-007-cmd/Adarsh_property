package com.eatm.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ResponseBody;

import com.eatm.Entity.Attendance;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

@Repository
public class AttendanceDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev1");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	public Attendance saveAttendance(Attendance attendance)
	{
		transaction.begin();
		manager.persist(attendance);
		transaction.commit();
		return attendance;
		
	}
	public Attendance mergeAttendance(Attendance attendance)
	{
		transaction.begin();
		manager.merge(attendance);
		transaction.commit();
		return attendance;
		
	}
	public Attendance deleteAttendance(Attendance attendance)
	{
		transaction.begin();
		manager.remove(attendance);
		transaction.commit();
		return attendance;
		
	}
	public Attendance findbyAttendanceId(long attendanceid)
	{
		
		return manager.find(Attendance.class, attendanceid);
	}
	public List<Attendance> fetchAttendance()
	{
		Query query = manager.createQuery("select attendance from Attendance attendance");
		List<Attendance> attendanceList = query.getResultList();
		
		if(attendanceList.size()>0)
		{
			return attendanceList;
		}
		return null;
	}
}
