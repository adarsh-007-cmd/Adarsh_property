package com.eatm.dao;


import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.eatm.Entity.Employee;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import jakarta.persistence.Query;

@Repository
public class EmployeeDAO {
	
	
	
	@Autowired
	EntityManager manager;
	@Autowired								
	EntityTransaction transaction;

public Employee saveEmployee(Employee employee)
{
transaction.begin();
manager.persist(employee);
transaction.commit();
return employee;
}
public Employee mergeEmployee(Employee employee)
{
transaction.begin();
manager.merge(employee);
transaction.commit();
return employee;
}
public Employee deleteEmployee(Employee employee)
{
transaction.begin();
manager.remove(employee);
transaction.commit();
return employee;
}
public Employee findByIdEmployees(long id)
{
return manager.find(Employee.class,id);

}
public List<Employee> fetchEmployees()
{
Query query = manager.createQuery("select employee from Employee employee");
List<Employee> employeesList = query.getResultList();

if(employeesList.size()>0)
{
return employeesList;
}
return null;
}
public Employee findByemailandpassword(String email, String password) {

	Query query = manager.createQuery("select employee from Employee employee where employee.email=?1 and employee.password=?2");
	query.setParameter(1, email);
	query.setParameter(2, password);
	List<Employee> employeeList = query.getResultList();
	if(employeeList.size()>0)
	{
		return employeeList.get(0);
	}
	return null;
}
public Employee findByemail(String email)
{
	Query query = manager.createQuery("select employee from Employee employee where employee.email=?1");
	query.setParameter(1, email);
	List<Employee> employeeList = query.getResultList();
	if(employeeList.size()>0)
	{
		return employeeList.get(0);
	}
	return null;
}
}
