package com.eatm.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.eatm.Entity.Address;
import com.eatm.Entity.Attendance;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

@Repository
public class AddressDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev1");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	public Address saveAddress(Address address)
	{
		transaction.begin();
		manager.persist(address);
		transaction.commit();
		return address;
	}
	public Address mergAddress(Address address)
	{
		transaction.begin();
		manager.merge(address);
		transaction.commit();
		return address;
	}
	public Address deleteAddress(Address address)
	{
		transaction.begin();
		manager.remove(address);
		transaction.commit();
		return address;
	}
	public Address findbyAddressId(long addressid)
	{
		
		return manager.find(Address.class, addressid);
	}
	
	public List<Address> fetchAddress()
	{
		Query query = manager.createQuery("select task from Task task");
		List<Address> addressList = query.getResultList();
		
		if(addressList .size()>0)
		{
			return addressList ;
		}
		return null;
	}
	
}
