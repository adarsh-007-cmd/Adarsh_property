<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Assign  - Task</title>
</head>
<body>
	<h1>Assign Task</h1>

<form action="assignTask" method="post">

    Task ID: <input type="number" name="taskid" required><br><br>
    Employee ID: <input type="number" name="employeeid" required><br><br>

    <input type="submit" value="Assign Task">

</form>
	

</body>
</html>