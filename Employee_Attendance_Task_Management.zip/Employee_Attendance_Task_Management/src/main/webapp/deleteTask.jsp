<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete Task</title>
</head>
<body>

<h1>Delete Task</h1>
<form action ="deleteTask" method="get">
		ENTER THE ID OF THE TASK TO FIND AND DELETE <input type="number" name="id" required>
		<input type="submit" value="Delete Task">
	</form>

</body>
</html>