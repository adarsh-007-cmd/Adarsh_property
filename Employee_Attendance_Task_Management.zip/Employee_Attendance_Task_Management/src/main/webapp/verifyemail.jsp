<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Email - Verification</title>
</head>
<body>
<h2>Verify Your Email</h2>
	
	<form action="verifyEmail">
		EMAIL : <input type="text" name="email" required>
		<input type="submit" value="Verify">
	
	</form>
</body>
</html>