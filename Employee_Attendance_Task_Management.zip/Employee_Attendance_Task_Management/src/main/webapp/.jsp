<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Email Verification</title>
</head>
<body>
<h1> Enter Your Email to verify </h1>
	<form action="verify">
		Email : <input type="text" name="email" required>
	<input type="submit" value="Verify"> 
</form>
</body>
</html>