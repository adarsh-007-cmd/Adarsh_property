<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Logged out</title>
</head>
<body>
<h1>Enter Your Employee ID to logout</h1>
<form action="logout" method="get">
	ATTENDANCE ID :<input type="number" name="id" required>
	
	<input type="submit" value="Logout">
</form>

</body>
</html>
