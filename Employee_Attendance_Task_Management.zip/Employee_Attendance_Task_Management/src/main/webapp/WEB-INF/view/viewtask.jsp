<%@page import="java.util.List"%>
<%@page import="com.eatm.Entity.Task"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Task</title>
</head>
<body>

	<h1>View Task</h1>


<%
    List<Task> tasks = (List<Task>) request.getAttribute("tasklist");
%>

<h1>Your Assigned Tasks</h1>

<table border="1">
    <tr>
        <th>Task ID</th>
        <th>Task Name</th>
        <th>Status</th>
    </tr>

<%
    for(Task task : tasks) {
%>

    <tr>
        <td><%= task.getTaskid() %></td>
        <td><%= task.getTaskname() %></td>
        <td><%= task.getStatus() %></td>
    </tr>

<%
    }
%>

	

</body>
</html>