<%@page import="com.eatm.Entity.Employee"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome To your Developer Dashboard</title>
</head>
<body>



<h1>Developer Dashboard</h1>
		<h2><a href="Updation.jsp">Updations</a></h2>
		<h2><a href="viewtask">View Task</a></h2>
		<h2><a href="changetaskstatus.jsp">Change- task -status</a></h2>
		<h2><a href="logout.jsp">Logout</a></h2>

</body>
</html>