<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome To The Login Page</title>
</head>
<body>
<h2>Login Credentials</h2>
	<form action="Login_page" method="get">
	
		EMAIL : <input type="text" name="email" required><br><br>
		PASSWORD : <input type="password" name="password" required><br><br>
		
		<input type="submit" value="login">
		
		<a href="verifyemail.jsp">Forgot Password</a><br><br>
		<a href="register.jsp">New User</a>
	</form>

</body>
</html>