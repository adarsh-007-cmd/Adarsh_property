<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Manager Dashboard</title>
</head>
<body>
	<h1>Manager Dashboard</h1>
	
	<h2><a href="addDeveloper.jsp">Add Developer</a></h2>
	<h2><a href="CreateTask.jsp">Create-Task</a></h2>
	<h2><a href="AssignTask.jsp">Assign-Task</a></h2>
	<h2><a href="viewalltaskwithdevelopers">ViewAllTaskWithDeveloper</a></h2>
	<h2><a href="deleteDeveloper.jsp">Delete Developer</a></h2>
	<h2><a href="deleteTask.jsp">Delete Task</a></h2>
	<h2><a href="logout.jsp">Logout</a></h2>
	

</body>
</html>