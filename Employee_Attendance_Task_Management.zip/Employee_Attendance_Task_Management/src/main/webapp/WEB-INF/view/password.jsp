<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Reset Your Password</title>
</head>
<body>
	<h1>Reset Your Password Here</h1>
	

<form action="password" method="post">

    <input type="hidden" name="email" value="${email}">

    NEW PASSWORD: <input type="password" name="password" required><br><br>

    <input type="submit" value="Reset Password">
</form>

</body>
</html>