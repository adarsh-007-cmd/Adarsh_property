<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Enter All Required Details to Update</title>
</head>
<body>
	<h1>Enter All Required Details to Update</h1>
	
	<form action="update" method="post">

<input type="hidden" name="id" value="${employee.id}"/>

NAME:
<input type="text" name="name" value="${employee.name}"><br><br>

EMAIL:
<input type="text" name="email" value="${employee.email}"><br><br>

PASSWORD:
<input type="password" name="password" value="${employee.password}"><br><br>

PHONE NUMBER:
<input type="number" name="phonenumber" value="${employee.phonenumber}"><br><br>

SALARY:
<input type="number" name="salary" value="${employee.salary}"><br><br>

HOUSE NUMBER:
<input type="text" name="address.housenumber" value="${employee.address.housenumber}"><br><br>

STREET:
<input type="text" name="address.street" value="${employee.address.street}"><br><br>

CITY:
<input type="text" name="address.city" value="${employee.address.city}"><br><br>

STATE:
<input type="text" name="address.state" value="${employee.address.state}"><br><br>

COUNTRY:
<input type="text" name="address.country" value="${employee.address.country}"><br><br>

PIN CODE:
<input type="number" name="address.pincode" value="${employee.address.pincode}"><br><br>

<input type="submit" value="Update">

</form>
</body>
</html>