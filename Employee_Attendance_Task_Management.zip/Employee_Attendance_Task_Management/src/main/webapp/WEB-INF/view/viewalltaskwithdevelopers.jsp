<%@page import="com.eatm.Entity.Employee"%>
<%@page import="com.eatm.Entity.Task"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View All Task With Developers</title>
</head>
<body>
	<h2>Task Assigned With Developers</h2>
	<table border="1">

<tr>
    <th>Task ID</th>
    <th>Task Name</th>
    <th>Days</th>
    <th>Status</th>
    <th>Employee</th>
</tr>

<%
    List<Task> list = (List<Task>) request.getAttribute("tasklist");

    if (list != null && !list.isEmpty()) {
        for (Task task : list) {
%>
<tr>
    <td><%= task.getTaskid() %></td>
    <td><%= task.getTaskname() %></td>
    <td><%= task.getDays() %></td>
    <td><%= task.getStatus() %></td>

    <td>
        <%
            Employee employee = task.getEmployee();
            if (employee != null) {
                out.print(employee.getName()); 
            } else {
                out.print("Not Assigned");
            }
        %>
    </td>
</tr>

<%
        }
    } else {
%>
<tr>
    <td colspan="5">No Tasks Available</td>
</tr>
<%
    }
%>

</table>

</body>
</html>