<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete - Developer</title>
</head>
<body>
	<h1>Remove Developer Details</h1>
	<form action ="deleteDeveloper" method="get">
		ENTER THE ID OF THE EMPLOYEE TO FIND AND DELETE <input type="number" name="id" required>
		<input type="submit" value="Delete Developer">
	</form>

</body>
</html>