<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Creat - Task</title>
</head>
<body>
	<h2>Create Task for the Developers</h2>

	<form action="createtask" method=get>
		ENTER TASK NAME : <input type="text" name="taskname" required><br><br>
		DURATION : <input type="text" name="days" required><br><br>
		
		<input type="submit" value="Create Task">
	
	</form>
	

</body>
</html>