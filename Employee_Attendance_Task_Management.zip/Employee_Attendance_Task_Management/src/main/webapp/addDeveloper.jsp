<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Developer</title>
</head>
<body>
	<form action="addDevloper" method="get">
	NAME : <input type="text" name="name" required><br><br>
	EMAIL : <input type="text" name="email" required><br><br>
	PASSWORD : <input type="password" name="password" required><br><br>
	PHONE NUMBER : <input type="number" name="phonenumber" required><br><br>
	SALARY : <input type="number" name="salary" required><br><br>
	
	HOUSE-NUMBER : <input type="text" name="housenumber" required><br><br>
	STREET : <input type="text" name="street" required><br><br>
	CITY : <input type="text" name="city" required><br><br>
	STATE : <input type="text" name="state" required><br><br>
	COUNTRY : <input type="text" name="country" required><br><br>
	PIN-CODE : <input type="text" name="pincode" required><br><br>
	
	<input type="submit" value="Add Developer">
</form>
</body>
</html>