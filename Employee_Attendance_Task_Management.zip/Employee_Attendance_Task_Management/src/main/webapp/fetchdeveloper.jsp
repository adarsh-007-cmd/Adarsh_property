<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>
<h1>Enter the ID to fetch Employee Tasks</h1>
	
	<form action ="fetchdevid" method="get">
		ID : <input type="number" name="employeeid" required>
		<input type="submit" value="Verify">
	</form>

</body>
</html>