<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Change Task Status </title>
</head>
<body>
	<h1>Change Task Status </h1>
	
	
	<form action="taskid" method="get">
	ENTER THE  TASK ID : <input type="number" name="taskid" required>
	
	<select name="status">
        <option value="CREATED">CREATED</option>
        <option value="ASSIGNED">ASSIGNED</option>
        <option value="COMPLETED">COMPLETED</option>
    </select><br><br>

    <input type="submit" value="Update Status">
    </form>

</body>
</html>