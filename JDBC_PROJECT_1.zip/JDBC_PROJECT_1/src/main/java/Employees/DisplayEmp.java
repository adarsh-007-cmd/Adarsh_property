package Employees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DisplayEmp {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
		Statement stat = connect.createStatement();
		
		ResultSet rSet = stat.executeQuery("select *from employees");
		
		while(rSet.next())
		{
			System.out.println(rSet.getString("empid"));
			System.out.println(rSet.getString("name"));
			System.out.println(rSet.getInt("salary"));
			System.out.println(rSet.getString("department"));
			
		}
		connect.close();
		
		
	} catch (Exception e) {
		System.out.println(e);
	}
}
}
