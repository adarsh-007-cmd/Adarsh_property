package Employees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class BonusUpdate {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
		PreparedStatement emp_bonus = connect.prepareStatement("update employees set salary=? where department=?");
		
	Scanner scan = new Scanner(System.in);
	
	
	
	
	System.out.println("Enter the previous salary : ");
	int salary = scan.nextInt();
	
	System.out.println("Enter the department : ");
	String department = scan.next();
	
	System.out.println("Enter the bonus amount :");
	int bonus = scan.nextInt();
	
	emp_bonus.setInt(1, salary);
	emp_bonus.setString(2, department);
	
	int rows =  emp_bonus.executeUpdate();
	if(rows!=0)
	{
		salary=salary+bonus;
		System.out.println(salary);
		
	}
	
	connect.close();	
	scan.close();
	} catch (Exception e) {
		System.out.println(e);
	}
}
}
