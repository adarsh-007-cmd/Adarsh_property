package Employees;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.sql.SQLException;

public class UpdateEmployee {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
		PreparedStatement pStat = connect.prepareStatement("update employees set name=?,salary=?,department=? where name=?");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the  Registered name :");
		String name = scan.next();
		System.out.println("Enter the new salary :");
		int salary = scan.nextInt();
		System.out.println("Enter the new department :");
		String department = scan.next();
		System.out.println("Enter the new name :");
		String new_name = scan.next();
		
		pStat.setString(1, new_name);
		
		pStat.setInt(2, salary);
		pStat.setString(3, department);
		pStat.setString(4, name);
		int rows = pStat.executeUpdate();
		if(rows!=0)
		{
			System.out.println("User is updated ");
		}
		else {
			System.out.println("user not found ");
		}
		connect.close();
		scan.close();
		
	} catch (Exception e) {
		System.out.println(e);
	}
}
}
