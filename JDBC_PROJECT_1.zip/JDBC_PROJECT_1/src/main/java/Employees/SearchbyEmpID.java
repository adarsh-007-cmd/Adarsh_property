package Employees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SearchbyEmpID {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
		PreparedStatement emp_search = connect.prepareStatement("select *from employees where empid=?");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the Employee ID :");
		int empid= scan.nextInt();
		emp_search.setInt(1, empid);
		
		ResultSet rSet = emp_search.executeQuery();
		while(rSet.next())
		{
			System.out.println(rSet.getString("empid"));
			System.out.println(rSet.getString("name"));
			System.out.println(rSet.getInt("salary"));
			System.out.println(rSet.getString("department"));
		}
		
	} catch (Exception e) {
		System.out.println(e);
	}
	
}
}
