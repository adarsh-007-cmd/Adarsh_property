package Employees;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class DeleteEmployee {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
			PreparedStatement emp_delete = connect.prepareStatement("delete from employees where empid=?");
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter the id Value : ");
			int empid = scan.nextInt();
			
			emp_delete.setInt(1, empid);
			
			int rows = emp_delete.executeUpdate();
			
			System.out.println("Are you sure? (Y/N)");
			char choice = scan.next().charAt(0);
			
			if(choice == 'Y')
			{
				System.out.println("Employee details has been removed successfully ..");
			}
			else {
				System.out.println("empid not found");
			}
			scan.close();
			connect.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
