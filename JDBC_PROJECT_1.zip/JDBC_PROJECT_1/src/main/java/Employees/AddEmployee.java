package Employees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.SQLException;

public class AddEmployee {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		
		Connection connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/company","postgres","postregsql");
		PreparedStatement emp_add = connect.prepareStatement("insert into employees(empid,Name,salary,department) values(?,?,?,?)");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the Employee ID :");
		int empid= scan.nextInt();
		
		System.out.println("Enter the Employee Name :");
		String Name = scan.next();
		
		System.out.println("Enter Salary:");
		int salary= scan.nextInt();
		
		System.out.println("Enter the Department Name :");
		String department = scan.next();
		
		emp_add.setInt(1, empid);
		emp_add.setString(2,Name);
		emp_add.setInt(3, salary);
		emp_add.setString(4,department);
		
		emp_add.execute();
		
		System.out.println(" A new Employee details has been added");
		 connect.close();
		scan.close();
			} catch (Exception e) {
		System.out.println(e);
	}
}
}
