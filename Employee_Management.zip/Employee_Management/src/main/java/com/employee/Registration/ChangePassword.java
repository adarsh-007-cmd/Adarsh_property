package com.employee.Registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/changePassword")
public class ChangePassword extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String password = req.getParameter("password");
		String idString = req.getParameter("id");
		
		PrintWriter printWriter = resp.getWriter();
		
		try {
			
		
		
		if(idString != null && !idString.isEmpty())
		{
			System.out.println("Field are required");
		}
		
		int id = Integer.parseInt(idString);
		
		try {
			
			Class.forName("org.postgresql.Driver");
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
			
			PreparedStatement preparedStatement = connection.prepareStatement("update employee set password=? where id=?");
			preparedStatement.setString(1, password);
			preparedStatement.setInt(2, id);
			
			int rows = preparedStatement.executeUpdate();
			if(rows != 0)
			{
				
				printWriter.print("<h2>Password has been updated</h2>");
				RequestDispatcher requestDispatcher = req.getRequestDispatcher("/login.html");
				requestDispatcher.forward(req, resp);
				
			}
			else {
				
				printWriter.print("<h2>Try Again</h2>");
				RequestDispatcher requestDispatcher = req.getRequestDispatcher("/takeNewPassword.html");
				requestDispatcher.forward(req, resp);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
