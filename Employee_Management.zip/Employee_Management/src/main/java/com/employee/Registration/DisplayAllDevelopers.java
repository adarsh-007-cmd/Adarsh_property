package com.employee.Registration;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import jakarta.servlet.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/viewDeveloper")
public class DisplayAllDevelopers extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ArrayList<DeveloperBeanClass> list = new ArrayList<>();
		
		try {
			Class.forName("org.postgresql.Driver");
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
			PreparedStatement preparedStatement = connection.prepareStatement("select * from employee where role='Developer'");
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				DeveloperBeanClass deveBeanClass = new DeveloperBeanClass();
				
				deveBeanClass.setId(resultSet.getInt("id"));
				deveBeanClass.setName(resultSet.getString("name"));
				deveBeanClass.setEmail(resultSet.getString("email"));
				deveBeanClass.setPassword(resultSet.getString("password"));
				deveBeanClass.setPhonenumber(resultSet.getLong("phonenumber"));
				deveBeanClass.setSalary(resultSet.getDouble("salary"));
				deveBeanClass.setRole(resultSet.getString("role"));
				
				list.add(deveBeanClass);
			}
			req.setAttribute("listofdevelopers", list);
			
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("displayDeveloper.jsp");
			requestDispatcher.forward(req, resp);
			
			resultSet.close();
			preparedStatement.close();
			connection.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
