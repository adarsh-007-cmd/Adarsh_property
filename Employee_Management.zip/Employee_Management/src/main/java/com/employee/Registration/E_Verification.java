package com.employee.Registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/verifyEmail")
public class E_Verification extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		PrintWriter printWriter = resp.getWriter();
		
		try {
			
			Class.forName("org.postgresql.Driver");
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
			PreparedStatement preparedStatement = connection.prepareStatement("select * from employee where email = ?");
			preparedStatement.setString(1,email);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				RequestDispatcher requestDispatcher = req.getRequestDispatcher("takeNewPassword.html");
				requestDispatcher.forward(req, resp);
			}
			else {
				printWriter.print("<h2>INVALID EMAIL</h2>");
				RequestDispatcher requestDispatcher = req.getRequestDispatcher("login.html");
				requestDispatcher.forward(req, resp);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
