package com.employee.Registration;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/check")
public class LoginServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("employee-email");
		String password = req.getParameter("employee-password");
		
		try {
			Class.forName("org.postgresql.Driver");
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
			
			PreparedStatement preparedStatement = connection.prepareStatement("select * from employee where email=? and password=?");
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			//PrintWriter printWriter = resp.getWriter();
			if(resultSet.next())
			{
				
					//printWriter.print("<h1>Login Successfull ! Welcome.</h1>");
					
					String role = resultSet.getString("role");
					System.out.println("Role = " + role);
					if(role.equals("ADMIN"))
					{
						RequestDispatcher requestDispatcher = req.getRequestDispatcher("/manager.html");
						requestDispatcher.forward(req, resp);
					}
					else if(role.equals("developer"))
					{
						RequestDispatcher requestDispatcher = req.getRequestDispatcher("/developer.html");
						requestDispatcher.forward(req, resp);
					}
				
				
			}
			else {
				
				//printWriter.print("<h3>Invalid Login</h3>");
				RequestDispatcher requestDispatcher = req.getRequestDispatcher("/login.html");
				requestDispatcher.include(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
