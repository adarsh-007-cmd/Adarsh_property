package com.employee.Registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/addDeveloper")
public class Developer extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String idString  = req.getParameter("developer-id");
		String name = req.getParameter("developer-name");
		String email  = req.getParameter("developer-email");
		String password  = req.getParameter("developer-password");
		String phonenumberString = req.getParameter("developer-phonenumber");
		String salaryString = req.getParameter("developer-salary");
		
		

			if(idString !=null && !idString.isEmpty() && name!= null && !name.isEmpty() &&
					email != null && !email.isEmpty() && password != null && !password.isEmpty() &&
					phonenumberString !=null && phonenumberString.isEmpty() && salaryString!=null && salaryString.isEmpty())
			{
				System.out.println("All fields are required :");
				return ;
			}
			
			try {
			
			long id = Long.parseLong(idString);
			long phonenumber = Long.parseLong(phonenumberString);
			double salary = Double.parseDouble(salaryString);
			
			try {
				
				Class.forName("org.postgresql.Driver");
				
				Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
				
				PreparedStatement preparedStatement = connection.prepareStatement("insert into employee(id,name,email,password,phonenumber,salary,role) values(?,?,?,?,?,?,?)");
				
				preparedStatement.setLong(1, id);
				preparedStatement.setString(2, name);
				preparedStatement.setString(3, email);
				preparedStatement.setString(4, password);
				preparedStatement.setLong(5, phonenumber);
				preparedStatement.setDouble(6, salary);
				preparedStatement.setString(7, "Developer");
				
				int rows = preparedStatement.executeUpdate();
				PrintWriter printWriter = resp.getWriter();
				
				if(rows!=0)
				{
					printWriter.print("<h1>Developer Registration Succussful</h1>");
				}
				else {
					printWriter.print("<h1>Registration Failed</h1>");
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
