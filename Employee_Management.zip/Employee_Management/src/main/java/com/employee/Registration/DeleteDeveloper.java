package com.employee.Registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class DeleteDeveloper extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	String idString = req.getParameter("id");
	PrintWriter printWriter = resp.getWriter();
	
	if(idString !=null && !idString.isEmpty())
	{
		return ;
	}
	try {
		
	
	int id = Integer.parseInt(idString);
	
	try {
		Class.forName("org.postgresql.Driver");
		Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee_management","postgres","12345");
		
		PreparedStatement preparedStatement = connection.prepareStatement("delete from employee where id=?");
		preparedStatement.setInt(1, id);
		
		int rows = preparedStatement.executeUpdate();
		
		if(rows != 0)
		{
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("delete.html");
			requestDispatcher.forward(req, resp);
		}
		else {
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("manager.html");
			requestDispatcher.include(req, resp);
		}
		preparedStatement.close();
		connection.close();
		
		
		
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	} catch (Exception e) {
		e.printStackTrace();
	}
	resp.getWriter().println("Deleted successfully");
	resp.sendRedirect("viewDeveloper");
}
}
