<%@page import="com.employee.Registration.DeveloperBeanClass"%>
<%@page import="java.util.ArrayList"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="com.sun.net.httpserver.Authenticator.Result"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>List of Developers - List</title>
</head>
<body>

	<h2>List of Developers</h2>
	
	<table border="1">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>PhoneNumber</th>
        <th>Salary</th>
        <th>Role</th>
    </tr>
    
    
	
	<%
		ArrayList<DeveloperBeanClass> list = (ArrayList<DeveloperBeanClass>) request.getAttribute("listofdevelopers");
	
		if(list != null)
		{
			for(DeveloperBeanClass dbc : list)

			{
				%>
			    <tr>
			        <td><%= dbc.getId() %></td>
			        <td><%= dbc.getName() %></td>
			        <td><%= dbc.getEmail() %></td>
			        <td><%= dbc.getPassword() %></td>
			        <td><%= dbc.getPhonenumber() %></td>
			        <td><%= dbc.getSalary() %></td>
			        <td><%= dbc.getRole() %></td>
			        
			    </tr>
			    
			<%
			
			}
			
		}
		else{
			%>
		    <tr>
		        <td colspan="8">No Data Found</td>
		    </tr>
		<%
		}
	%>
	</table>
	
</body>
</html>